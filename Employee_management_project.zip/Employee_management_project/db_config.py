import mysql.connector

def get_connection():
    return mysql.connector.connect(
        host="localhost",
        user="root",
        password="",  # Leave empty if no password is set in XAMPP
        database="employee_db"
    )
