from flask_restful import Resource, reqparse
from db_config import get_connection

parser = reqparse.RequestParser()
parser.add_argument('name')
parser.add_argument('dept')
parser.add_argument('salary')

class EmployeeAPI(Resource):
    def get(self, emp_id=None):
        conn = get_connection()
        cursor = conn.cursor(dictionary=True)
        if emp_id:
            cursor.execute("SELECT * FROM employees WHERE id = %s", (emp_id,))
            data = cursor.fetchone()
        else:
            cursor.execute("SELECT * FROM employees")
            data = cursor.fetchall()
        conn.close()
        return data

    def post(self):
        args = parser.parse_args()
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("INSERT INTO employees (name, dept, salary) VALUES (%s, %s, %s)",
                       (args['name'], args['dept'], args['salary']))
        conn.commit()
        conn.close()
        return {"message": "Employee added"}, 201

    def put(self, emp_id):
        args = parser.parse_args()
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("UPDATE employees SET name=%s, dept=%s, salary=%s WHERE id=%s",
                       (args['name'], args['dept'], args['salary'], emp_id))
        conn.commit()
        conn.close()
        return {"message": "Employee updated"}, 200

    def delete(self, emp_id):
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("DELETE FROM employees WHERE id=%s", (emp_id,))
        conn.commit()
        conn.close()
        return {"message": "Employee deleted"}, 204
