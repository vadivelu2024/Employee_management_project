import logging


# print('app started')

logging.basicConfig(level=logging.INFO)
logging.info('db connected')