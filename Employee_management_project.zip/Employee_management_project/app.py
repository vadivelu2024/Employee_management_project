from flask import Flask, render_template, request, redirect, url_for
from flask_restful import Api
from api.employee_api import EmployeeAPI
from utils.error_handler import handle_exception
from db_config import get_connection

app = Flask(__name__)
api = Api(app)

app.register_error_handler(Exception, handle_exception)
api.add_resource(EmployeeAPI, "/api/employees", "/api/employees/<int:emp_id>")

@app.route('/')
def home():
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM employees")
    employees = cursor.fetchall()
    conn.close()
    return render_template("home.html", employees=employees)

@app.route('/add', methods=['GET', 'POST'])
def add_employee():
    if request.method == 'POST':
        name = request.form['name']
        dept = request.form['dept']
        salary = request.form['salary']
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("INSERT INTO employees(name, dept, salary) VALUES (%s, %s, %s)",
                       (name, dept, salary))
        conn.commit()
        conn.close()
        return redirect(url_for('home'))
    return render_template("add_employee.html")

@app.route('/update/<int:id>', methods=['GET', 'POST'])
def update_employee(id):
    conn = get_connection()
    cursor = conn.cursor(dictionary=True)
    if request.method == 'POST':
        name = request.form['name']
        dept = request.form['dept']
        salary = request.form['salary']
        cursor.execute("UPDATE employees SET name=%s, dept=%s, salary=%s WHERE id=%s",
                       (name, dept, salary, id))
        conn.commit()
        conn.close()
        return redirect(url_for('home'))
    cursor.execute("SELECT * FROM employees WHERE id=%s", (id,))
    employee = cursor.fetchone()
    conn.close()
    return render_template("update_employee.html", employee=employee)

@app.route('/delete/<int:id>')
def delete_employee(id):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM employees WHERE id=%s", (id,))
    conn.commit()
    conn.close()
    return redirect(url_for('home'))

if __name__ == '__main__':
    app.run(debug=True)
